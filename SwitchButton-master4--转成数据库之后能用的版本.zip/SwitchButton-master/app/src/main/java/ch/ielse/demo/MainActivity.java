package ch.ielse.demo;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteTransactionListener;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private MyDBOpenHelper myDBHelper;
    private SQLiteDatabase db;
    private Context mContext;
    private StringBuilder sb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mContext = MainActivity.this;
        myDBHelper = new MyDBOpenHelper(mContext, "my.db", null , 1);
        db = myDBHelper.getWritableDatabase();
        ContentValues values =  new ContentValues();
        values.put("time","Hhh");
        values.put("appName", "yunyun");
        values.put("methodName","method1");
        db.insert("Log", null, values);

        sb = new StringBuilder();
        //参数依次是:表名，列名，where约束条件，where中占位符提供具体的值，指定group by的列，进一步约束
        //指定查询结果的排序方式
//        String[] whereClause = new String[1]={"state"};
//        Cursor cursor = db.query("AppState", new String[]{"packageName", "appName", "state"}, "appName=?", new String[]{"yunyun"}, null, null, null);
        Cursor cursor = db.query("Log", null, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex("id"));
                String time = cursor.getString(cursor.getColumnIndex("time"));
                String appName = cursor.getString(cursor.getColumnIndex("appName"));
                String methodName = cursor.getString(cursor.getColumnIndex("methodName"));
//                Log.i("tag", id+"  "+ time + "  " + appName + "  " + methodName);
                sb.append(id + "  "+ time + "  " + appName + "  " + methodName + "\n");
            } while (cursor.moveToNext());
        }
        cursor.close();
        Toast.makeText(mContext, sb.toString(), Toast.LENGTH_SHORT).show();

        findViewById(R.id.b_normal).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, NormalActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.b_api_intro).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, APIIntroActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.b_size_intro).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SizeIntroActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.b_list).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ListActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.b_func).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, FuncActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.b_log).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, LogActivity.class);
                startActivity(intent);
            }
        });
    }
}
