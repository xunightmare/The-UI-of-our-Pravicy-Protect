package ch.ielse.demo;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toolbar;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class LogActivity extends AppCompatActivity {
    TextView textView;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log);

//        ((Toolbar) findViewById(R.id.toolbar)).setNavigationOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                LogActivity.this.finish();
//            }
//        });
        ((android.support.v7.widget.Toolbar) findViewById(R.id.toolbar)).setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LogActivity.this.finish();
            }
        });
        button = (Button) findViewById(R.id.button1);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String filename = "log.txt";
                MyDBOpenHelper myDBHelper = new MyDBOpenHelper(LogActivity.this, "my.db", null , 1);
                SQLiteDatabase db = myDBHelper.getWritableDatabase();
                db.execSQL("delete from Log");
                LogActivity.this.finish();
                Intent intent = new Intent(LogActivity.this, LogActivity.class);
                startActivity(intent);
            }

        });

        List<MyLog> logList = new ArrayList<MyLog>();
        MyDBOpenHelper myDBHelper = new MyDBOpenHelper(LogActivity.this, "my.db", null , 1);
        SQLiteDatabase db = myDBHelper.getWritableDatabase();
        Cursor cursor = db.query("Log", new String[]{"id", "time", "appName", "methodName"}, null, null, null, null, null);
        String aLog;
        while(cursor.moveToNext()){
            int id = cursor.getInt(0);
            String time = cursor.getString(1);
            String appName = cursor.getString(2);
            String methodName = cursor.getString(3);
            aLog =id + "  " + time + "  " + appName + "  " + methodName + "\n";
            Log.i("tag", id + "  " + time + "  " + appName + "  " + methodName + "\n");
            MyLog log = new MyLog(id, time, appName, methodName);
            logList.add(log);
        }

        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.linearLayout_log);
        //把数据显示至屏幕
        for (MyLog log : logList) {
            TextView tv = new TextView(this);
            tv.setText(log.getId() + "   " + log.getTime() + "   " + log.getAppName() + "   " + log.getModuleName());
            Log.i("tag", log.toString());
            tv.setTextSize(18);
            linearLayout.addView(tv);
        }



//        readFromRaw();
    }
//    private void readFromRaw() {
//        try {
//            String fileName = "log.txt";
//            FileInputStream inputStream = this.openFileInput(fileName);
//            byte[] bytes = new byte[1024];
//            ByteArrayOutputStream arrayOutputStream = new ByteArrayOutputStream();
//            while (inputStream.read(bytes) != -1) {
//                arrayOutputStream.write(bytes, 0, bytes.length);
//            }
//            inputStream.close();
//            arrayOutputStream.close();
//            String content = new String(arrayOutputStream.toByteArray());
//
//            textView.setText(content);
//
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//
//    }


}
