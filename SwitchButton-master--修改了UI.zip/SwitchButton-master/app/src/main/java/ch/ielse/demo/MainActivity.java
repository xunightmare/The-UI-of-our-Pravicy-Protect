package ch.ielse.demo;

import android.app.ActivityGroup;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TabHost;

public class MainActivity extends ActivityGroup {
    private TabHost mTabHost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        int screenWidth = this.getWindowManager().getDefaultDisplay().getWidth();
        initTabs();
    }

    private void initTabs() {
        mTabHost = (TabHost) findViewById(R.id.tabhost);
        mTabHost.setup(this.getLocalActivityManager());
        // 添加日志列表的tab,注意下面的setContent中的代码.是这个需求实现的关键

        mTabHost.addTab(mTabHost.newTabSpec("tab_setting")
                .setIndicator("功能开关",getResources().getDrawable(R.drawable.btn_choose))
                .setContent(new Intent(this, ModuleListActivity.class)));

        // 添加应用设置的tab,注意下面的setContent中的代码.是这个需求实现的关键
        mTabHost.addTab(mTabHost.newTabSpec("tab_applist")
                .setIndicator("应用列表",getResources().getDrawable(R.drawable.btn_choose))
                .setContent(new Intent(this, AppListActivity.class)));

        mTabHost.addTab(mTabHost.newTabSpec("tab_log")
                .setIndicator("查看日志",getResources().getDrawable(R.drawable.btn_choose))
                .setContent(new Intent(this, LogActivity.class)));

        mTabHost.setCurrentTab(1);


    }


}
