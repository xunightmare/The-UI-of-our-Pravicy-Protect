package ch.ielse.demo;

/**
 * Created by LY on 2016/9/13.
 */
public class ItemObject {
    String title;
    boolean isOpened;
}
