package ch.ielse.demo;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class LogActivity extends AppCompatActivity {
    private Button button;
    private List<MyLog> logList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log);

        // 监听Toolbar
        ((android.support.v7.widget.Toolbar) findViewById(R.id.toolbar)).setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LogActivity.this.finish();
            }
        });

        // 监听button，用来清库
        button = (Button) findViewById(R.id.button1);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyDBOpenHelper myDBHelper = new MyDBOpenHelper(LogActivity.this, "my.db", null , 1);
                SQLiteDatabase db = myDBHelper.getWritableDatabase();
                db.execSQL("delete from Log");  // 清库
                //清库后重新启动
                LogActivity.this.finish();
                Intent intent = new Intent(LogActivity.this, LogActivity.class);
                startActivity(intent);
            }
        });

//        显示日志
//        从日志中读出所有的记录，保存到列表中
        logList = new ArrayList<MyLog>();
        MyDBOpenHelper myDBHelper = new MyDBOpenHelper(LogActivity.this, "my.db", null , 1);
        SQLiteDatabase db = myDBHelper.getWritableDatabase();
        Cursor cursor = db.query("Log", new String[]{"id", "time", "appName", "methodName"}, null, null, null, null, null);
        String aLog;
        while(cursor.moveToNext()){
            int id = cursor.getInt(0);
            String time = cursor.getString(1);
            String appName = cursor.getString(2);
            String methodName = cursor.getString(3);
            aLog =id + "  " + time + "  " + appName + "  " + methodName + "\n";
            Log.i("tag", id + "  " + time + "  " + appName + "  " + methodName + "\n");
            MyLog log = new MyLog(id, time, appName, methodName);
            logList.add(log);
        }

        //把数据显示至屏幕
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.linearLayout_log);
        for (MyLog log : logList) {
            TextView tv = new TextView(this);
            tv.setText(log.getId() + "   " + log.getTime() + "   " + log.getAppName() + "   " + log.getModuleName());
            Log.i("tag", log.toString());
            tv.setTextSize(18);
            linearLayout.addView(tv);
        }
    }
}
