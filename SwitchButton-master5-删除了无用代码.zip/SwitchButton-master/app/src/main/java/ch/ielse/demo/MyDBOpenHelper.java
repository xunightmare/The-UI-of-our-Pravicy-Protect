package ch.ielse.demo;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDBOpenHelper extends SQLiteOpenHelper {
    public MyDBOpenHelper(Context context, String name, SQLiteDatabase.CursorFactory factory,
                          int version) {super(context, "my.db", null, 1); }
    @Override
    //数据库第一次创建时被调用
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE AppState(packageName VARCHAR(100) PRIMARY KEY, appName VARCHAR(50) unique, state integer)");
        db.execSQL("CREATE TABLE ModuleState(moduleName VARCHAR(20) PRIMARY KEY, methodName VARCHAR(50), state integer)");
        db.execSQL("CREATE TABLE Log(id integer primary key autoincrement, time VARCHAR(20), appName VARCHAR(50), methodName VARCHAR(50))");
    }
    //软件版本号发生改变时调用
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("ALTER TABLE person ADD phone VARCHAR(12) ");
    }

    public static boolean changeIntToBool(int i){
        if (i == 0){
            return false;
        }else {
            return  true;
        }
    }

    public static int changeBoolToInt(Boolean b){
        if (b == false){
            return 0;
        }else {
            return  1;
        }
    }

}