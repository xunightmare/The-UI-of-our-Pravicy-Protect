package ch.ielse.demo;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import ch.ielse.view.SwitchView;

import static android.app.PendingIntent.getActivity;

public class ListActivity extends AppCompatActivity {


    private ListView vList;
    private ItemListAdapter adapter;
    public Handler mHandler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        ((Toolbar) findViewById(R.id.toolbar)).setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ListActivity.this.finish();
            }
        });


        vList = (ListView) findViewById(R.id.v_list);
        vList.setAdapter(adapter = new ItemListAdapter());
        initAppList();
    }

    private void initAppList() {
        new Thread() {
            @Override
            public void run() {
                super.run();
                //扫描得到APP列表
                final List<MyAppInfo> appInfos = ApkTool.scanLocalInstallAppList(ListActivity.this.getPackageManager());
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        adapter.setData(appInfos);
                    }
                });
            }
        }.start();
    }

    private class ItemListAdapter extends BaseAdapter {

        List<ItemObject> mDataList = new ArrayList<ItemObject>();
        List<MyAppInfo> myAppInfos = new ArrayList<MyAppInfo>();


        public void setData(List<MyAppInfo> myAppInfos) {
            mDataList.clear();
//            Log.i("tag", String.valueOf(myAppInfos.size()));
            for (int i = 0; i < myAppInfos.size(); i++) {
                ItemObject itemObject = new ItemObject();
                itemObject.title = "item[" + i + "]";
                mDataList.add(itemObject);
            }
            this.myAppInfos = myAppInfos;
            notifyDataSetChanged();
        }


            private class ViewHolder implements View.OnClickListener {
            View itemView;
            ImageView image;
            TextView tTitle;
            SwitchView vSwitch;
            ItemObject itemObject;
            int pos;

            ViewHolder(View view) {
                this.itemView = view;
            }

            @Override
            public void onClick(View v) {
                if (v == vSwitch) {
                    itemObject.isOpened = vSwitch.isOpened();
                    SharedPreferences settings = getSharedPreferences("settings",0);
                    Boolean aBool = settings.getBoolean(tTitle.getText().toString(),false);
                    Boolean bBool = settings.getBoolean(tTitle.getText().toString(),true);
                    SharedPreferences.Editor editor = settings.edit();
                    editor
                            .putBoolean(tTitle.getText().toString(),itemObject.isOpened)
                            .commit();
                    Boolean cBool = settings.getBoolean(tTitle.getText().toString(),true);
                    Boolean dBool = settings.getBoolean(tTitle.getText().toString(),false);
                    Toast.makeText(v.getContext().getApplicationContext(), "vSwitch[" + tTitle.getText() + "] change to " + itemObject.isOpened, Toast.LENGTH_SHORT).show();
                }
            }
        }

        @Override
        public int getCount() {
            return myAppInfos.size();
        }

        @Override
        public Object getItem(int position) {
            return mDataList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_list_content, parent, false);
            }
            ViewHolder viewHolder = (ViewHolder) convertView.getTag();
            MyAppInfo myAppInfo = myAppInfos.get(position);
            if (viewHolder == null) {
                viewHolder = new ViewHolder(convertView);
                convertView.setTag(viewHolder);
                viewHolder.image = (ImageView) convertView.findViewById(R.id.iv_app_icon);
                viewHolder.tTitle = (TextView) convertView.findViewById(R.id.t_title);
                viewHolder.vSwitch = (SwitchView) convertView.findViewById(R.id.v_switch);
                viewHolder.vSwitch.setOnClickListener(viewHolder);
            }

            viewHolder.pos = position;
            viewHolder.image.setImageDrawable(myAppInfo.getImage());
            viewHolder.itemObject = (ItemObject) getItem(position);
            viewHolder.tTitle.setText(myAppInfo.getAppName());
//            viewHolder.vSwitch.setOpened(viewHolder.itemObject.isOpened);

//            Log.i("tag", "forward");
            SharedPreferences settings = getSharedPreferences("settings",0);
//            Log.i("tag", "backward");
//            String path1 = getApplicationContext().getFilesDir().getAbsolutePath();
//            Log.i("tag", path1);
//            String path2 = Environment.getExternalStorageDirectory().toString();
//            Log.i("tag", path2);
            Boolean aBool = settings.getBoolean(myAppInfo.getAppName(),false);
            Log.i("tag",aBool.toString());
            SharedPreferences.Editor editor = settings.edit();
            editor.putBoolean(myAppInfo.getAppName(),aBool).commit();
//            Boolean bBool = settings.getBoolean(myAppInfo.getAppName(),false);
//            Log.i("tag",bBool.toString());
            viewHolder.vSwitch.setOpened(aBool);



            viewHolder.itemView.setBackgroundColor(position % 2 != 0 ? 0xFFFFFFFF : 0xFFEEEFF3);
            return convertView;
        }
    }
}
