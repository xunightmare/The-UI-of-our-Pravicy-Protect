package ch.ielse.demo;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import ch.ielse.view.SwitchView;

public class FuncActivity extends AppCompatActivity {

    private ListView vfunc;
    private ItemListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_func);

        ((Toolbar) findViewById(R.id.toolbar)).setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FuncActivity.this.finish();
            }
        });


        vfunc = (ListView) findViewById(R.id.v_func);
        vfunc.setAdapter(adapter = new ItemListAdapter());

        adapter.set();
    }

    private class ItemListAdapter extends BaseAdapter {

        List<ItemObject> mDataList = new ArrayList<ItemObject>();

        void addItem(String name){
            ItemObject itemObject = new ItemObject();
            itemObject.title = name;
            mDataList.add(itemObject);
        }

        public void set() {
            mDataList.clear();
            addItem("监控通讯录");
            addItem("监控摄像头");
            addItem("监控信息");
            addItem("监控话筒");

            notifyDataSetChanged();
        }

        private class ViewHolder implements View.OnClickListener {
            View itemView;
            TextView tTitle;
            SwitchView vSwitch;
            ItemObject itemObject;
            int pos;

            ViewHolder(View view) {
                this.itemView = view;
            }

            @Override
            public void onClick(View v) {
                if (v == vSwitch) {
                    itemObject.isOpened = vSwitch.isOpened();

                    SharedPreferences settings = getSharedPreferences("settings",0);
                    Boolean aBool = settings.getBoolean("监控通讯录",false);
                    Boolean bBool = settings.getBoolean("监控摄像头",false);
                    Boolean cBool = settings.getBoolean("监控信息",false);
                    Boolean dBool = settings.getBoolean("监控话筒",false);
                    Log.i("test","监控通讯录 "+aBool.toString());
                    Log.i("test","监控摄像头 "+bBool.toString());
                    Log.i("test","监控信息 "+cBool.toString());
                    Log.i("test","监控话筒 "+dBool.toString());
//                    Boolean bBool = settings.getBoolean(tTitle.getText().toString(),true);
                    SharedPreferences.Editor editor = settings.edit();
                    editor
                            .putBoolean(tTitle.getText().toString(),itemObject.isOpened)
                            .commit();
                    String filename = "log.txt";
                    try{
                        FileOutputStream outputStream = openFileOutput(filename, Activity.MODE_APPEND);
                        String temp = "[" + tTitle.getText() + "] change to " + itemObject.isOpened+'\n';
                        outputStream.write(temp.getBytes());
                        outputStream.flush();
                        outputStream.close();
                    }catch (FileNotFoundException e){
                        e.printStackTrace();
                    }catch (IOException e){
                        e.printStackTrace();
                    }

//                    Boolean cBool = settings.getBoolean(tTitle.getText().toString(),true);
//                    Boolean dBool = settings.getBoolean(tTitle.getText().toString(),false);
                    Toast.makeText(v.getContext().getApplicationContext(), "vSwitch[" + tTitle.getText() + "] change to " + itemObject.isOpened, Toast.LENGTH_SHORT).show();
                }
            }
        }

        @Override
        public int getCount() {
            return mDataList.size();
        }

        @Override
        public Object getItem(int position) {
            return mDataList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_list_content, parent, false);
            }
            ViewHolder viewHolder = (ViewHolder) convertView.getTag();
            if (viewHolder == null) {
                viewHolder = new ViewHolder(convertView);
                convertView.setTag(viewHolder);
                viewHolder.tTitle = (TextView) convertView.findViewById(R.id.t_title);
                viewHolder.vSwitch = (SwitchView) convertView.findViewById(R.id.v_switch);
                viewHolder.vSwitch.setOnClickListener(viewHolder);
            }

            viewHolder.pos = position;
            viewHolder.itemObject = (ItemObject) getItem(position);
            viewHolder.tTitle.setText(viewHolder.itemObject.title);


            SharedPreferences settings = getSharedPreferences("settings",0);
            Boolean aBool = settings.getBoolean(viewHolder.itemObject.title,true);
            Boolean fBool = settings.getBoolean(viewHolder.itemObject.title,false);
            Log.i("tag",viewHolder.itemObject.title);
            SharedPreferences.Editor editor = settings.edit();
            editor.putBoolean(viewHolder.tTitle.toString(),aBool).commit();
            viewHolder.vSwitch.setOpened(aBool);


            viewHolder.itemView.setBackgroundColor(position % 2 != 0 ? 0xFFFFFFFF : 0xFFEEEFF3);
            return convertView;
        }
    }
}
