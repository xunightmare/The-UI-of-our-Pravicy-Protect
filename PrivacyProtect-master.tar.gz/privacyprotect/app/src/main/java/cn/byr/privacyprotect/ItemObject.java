package cn.byr.privacyprotect;

public class ItemObject {
    String title;
    boolean isOpened;
}
